# Hack2Hire – AI Mock Interview Platform

## How to Run
1. Install Python & Flask
2. Run backend:
   python backend/app.py
3. Open frontend/index.html in browser

## Features
- AI Interviewer
- Adaptive Difficulty
- Time-based Evaluation
- Interview Readiness Score
